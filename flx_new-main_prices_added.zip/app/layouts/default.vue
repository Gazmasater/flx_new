<template>
  <slot />
</template>