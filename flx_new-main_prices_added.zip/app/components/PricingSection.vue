<script setup lang="ts">
defineProps<{
  prices: Array<{
    title: string;
    description: string;
    price: string;
  }>;
}>();
</script>

<template>
  <section id="pricing" class="section pricing-section">
    <div class="section-heading">
      <p class="eyebrow">Стоимость</p>
      <h2>Услуги и цены</h2>
      <p>
        Сервис оказывает информационно-технологические услуги по обработке пользовательских заявок,
        техническому сопровождению, информационной поддержке, AML/KYC-проверке и взаимодействию с партнёрами.
      </p>
    </div>

    <div class="price-table" aria-label="Услуги и стоимость">
      <article v-for="item in prices" :key="item.title" class="price-row">
        <div>
          <h3>{{ item.title }}</h3>
          <p>{{ item.description }}</p>
        </div>
        <strong>{{ item.price }}</strong>
      </article>
    </div>

    <p class="pricing-note">
      Итоговая стоимость услуги рассчитывается индивидуально и зависит от суммы заявки, способа исполнения,
      рыночных условий, инфраструктурных расходов, уровня риска операции, необходимости проведения AML/KYC-проверки
      и условий взаимодействия с партнёрами. Итоговая стоимость отображается пользователю до подтверждения заявки.
    </p>
  </section>
</template>
